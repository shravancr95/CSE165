#include "Functions.h"

namespace MyLib{
    void someFunction(){
        std::cout << "someFunction" << std::endl;
    }
};
